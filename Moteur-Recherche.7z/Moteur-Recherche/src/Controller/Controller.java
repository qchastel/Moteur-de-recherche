package Controller;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Index;
import application.IndexInvers�;
import application.Lancement;
import application.ModeleBooleen;
import application.ModeleVectoriel;
import application.TraitementTexte;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField and;

    @FXML
    private TextField or;

    @FXML
    private TextField not;

    @FXML
    private Button go;

    @FXML
    private ChoiceBox<String> choix;

    @FXML
    void initialize() {
    	Index index = new Index();
		IndexInvers� indexI = new IndexInvers�();
		TraitementTexte tTexte = new TraitementTexte();
    	try {
			Lancement.modele(index,indexI,tTexte);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
		ModeleBooleen mb=new ModeleBooleen(new TraitementTexte(),new Index(),new IndexInvers�());
		ModeleVectoriel mv = new ModeleVectoriel();
    	
    	choix.getItems().add("Booleen");
		choix.getItems().add("Vectorielle");
		choix.getItems().add("Probabiliste");
    	
    	go.setOnAction(e -> {
    		//if(choix.getSelectionModel().equals("Booleen"))
    			mb.resultat(and.getText(), or.getText(), not.getText());
    	//	else if(choix.getSelectionModel().equals("Vectorielle"))
    	//		mv.getDocuments(and.getText());
    		});
    }
}
