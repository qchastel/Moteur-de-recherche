package application;


public class Frequences {
	
	private int nbOccurence ;
	private double frequence ;
	private double tfidf;
	
	public int getNbOccurence() {
		return nbOccurence;
	}
	
	public double getFrequence() {
		return frequence;
	}
	
	public double getTfidf() {
		return tfidf;
	}
	
	
	
	
}
