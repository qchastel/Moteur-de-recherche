package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeSet;

public class ModeleBooleen {

	public ArrayList<Map<Doc, Integer>> and;
	public ArrayList<Map<Doc, Integer>> or;
	public ArrayList<Map<Doc, Integer>> not;
	public TraitementTexte tT;
	public Index i;
	public IndexInvers� iI;

	public ModeleBooleen(TraitementTexte t, Index index, IndexInvers� indexI) {
		tT = t;
		i = index;
		iI = indexI;
	}

	public ArrayList<Doc> resultat(String s1, String s2, String s3) {
		and = resultatReq(tT.traiteTexte(s1));
		or = resultatReq(tT.traiteTexte(s2));
		not = resultatReq(tT.traiteTexte(s3));
		ArrayList<Doc> result = new ArrayList<>();
		if (and.size() > 0) {

			for (Map<Doc, Integer> hashMap : and) {
				if(hashMap!=null)
					result.addAll(hashMap.keySet());

			}
			result = and(result, and.size());
		}
		ArrayList<Doc> resultOr = new ArrayList<>();
		if(or.size()>0) {
			
			for (Map<Doc, Integer> hashMap : or) {
				if(hashMap!=null)
					resultOr.addAll(hashMap.keySet());

			}
			result = or(result, resultOr);
		}
		ArrayList<Doc> resultNot = new ArrayList<>();
		if(not.size()>0) {
			
			for (Map<Doc, Integer> hashMap : not) {
				if(hashMap!=null)
					resultNot.addAll(hashMap.keySet());

			}
			result = not(result, resultNot);
		}
		

		return result;
	}

	public ArrayList<Map<Doc, Integer>> resultatReq(ArrayList<String> al) {
		ArrayList<Map<Doc, Integer>> listDoc = new ArrayList<>();
		for (String string : al) {
			listDoc.add(iI.registreMots.get(string));

			System.out.println(string);
			System.out.println(listDoc);
		}

		return listDoc;
	}

	public ArrayList<Doc> and(ArrayList<Doc> result, int nb) {
		Map<Doc, Integer> map = new HashMap<Doc, Integer>();
		ArrayList<Doc> result2 = new ArrayList();
		for (int i = 0; i < result.size(); i++) {
			if (!map.containsKey(result.get(i)))
				map.put(result.get(i), 1);
			else if (map.get(result.get(i)) + 1 == nb)
				result2.add(result.get(i));
			map.put(result.get(i), map.get(result.get(i)) + 1);
		}

		return result2;
	}
	

	public ArrayList<Doc> or(ArrayList<Doc> result, ArrayList<Doc> or){
	
		ArrayList<Doc> result2= new ArrayList();
		for(int i=0;i<or.size();i++) {
			if(result.contains(or.get(i)))
				result2.add(result.get(i));	
		}
		return result2;
	}
	public ArrayList<Doc> not(ArrayList<Doc> result, ArrayList<Doc> not){
	
		ArrayList<Doc> result2= new ArrayList();
		for(int i=0;i<not.size();i++) {
			if(!result.contains(not.get(i)))
				result2.add(not.get(i));	
		}
		return result2;
	}

	/*
	 * public String transformationEnReq(String expressionExacte,String mots,String
	 * auMoins,String pasCeMot) { ArrayList<String> nvExpressionExacte = new
	 * ArrayList<>(); nvExpressionExacte = tT.traiteTexte(expressionExacte);
	 * if(nvExpressionExacte!=null) {
	 * 
	 * return expressionExacte; }else {
	 * 
	 * return mots+"^AND^"+auMoins+"^OR^"+auMoins+"^NOT^"+pasCeMot; } }
	 */
	/*
	 * public void requete(String arguments){ ArrayList<String>
	 * motsTraites=tT.traiterTexte(arguments); ArrayList<String> docChemin = new
	 * ArrayList<>();
	 * 
	 * for(String s : motsTraites) { docChemin.addAll(a.get(s)); }
	 * 
	 * HashMap<String,Integer> c = new HashMap<>(); for(int i = 0; i<
	 * docChemin.size();i++) { c.put(docChemin.get(i), 0); docChemin.remove(0);
	 * for(int y=i;y<docChemin.size();y++) {
	 * if(docChemin.get(i).equals(docChemin.get(y))) { c.replace(docChemin.get(i),
	 * c.get(docChemin.get(i))+1); docChemin.remove(y); } } }
	 * 
	 * }
	 * 
	 * 
	 * public HashSet<String> recherche(String requete){
	 * 
	 * HashMap<HashMap<String,String>,Integer> incidenceTermeDocument = new
	 * HashMap<>();
	 * 
	 * String[] decoupage,decoupageAND,decoupageOR,decoupageNOT; boolean
	 * booleenDecoupage,booleenDecoupageAND,booleenDecoupageOR,booleenDecoupageNOT;
	 * decoupageNOT = requete.split("^NOT^"); if(decoupageNOT.length > 1)
	 * booleenDecoupageNOT=true; else booleenDecoupageNOT=false; decoupageOR =
	 * requete.split("^OR^"); if(decoupageOR.length > 1) booleenDecoupageOR=true;
	 * else booleenDecoupageOR=false; decoupageAND = requete.split("^AND^");
	 * if(decoupageOR.length > 1) booleenDecoupageAND=true; else
	 * booleenDecoupageAND=false;
	 * 
	 * ArrayList<String> decoupageArray = new ArrayList<>();
	 * 
	 * decoupage = requete.split("^AND^","^OR^","^NOT^"); for (int i = 0; i <
	 * decoupage.length; i++) { decoupageArray.add(decoupage[i]); }
	 * 
	 * 
	 * 
	 * }
	 */

}
