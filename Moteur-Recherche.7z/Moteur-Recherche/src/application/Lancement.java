package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.SortedMap;

public class Lancement {

	public static void modele(Index index, IndexInvers� indexI,TraitementTexte tTexte) throws IOException {

		
		indexI.indexation(tTexte.traiteTexte("Emilie me fait chier Emilie me fait chier"),new Doc("a", "Emilie me fait chier. Et oui, ah 11 11 33 55 Emilie me fait chier. Et oui, ah 11 11 33 55"));
		System.out.println(indexI.registreMots.get("Emili"));
		indexI.indexation(tTexte.traiteTexte("Emilie me fait chier Emilie me fait chier"),new Doc("e", "Emilie me fait chier. Et oui, ah 11 11 33 55 Emilie me fait chier. Et oui, ah 11 11 33 55"));
		System.out.println(indexI.registreMots.get("emili"));
		Crawler c = new Crawler(index, indexI, tTexte);
		
		
		System.out.println(indexI.registreMots.get("soldi"));
		//String chemin = "src/ressources/NYT20000531.0316";

		
	//	Doc d = new Doc(chemin,c.parcoursTermes(chemin));
		
		//ModeleBooleen mD= new ModeleBooleen();
	 
	    // Creer un tableau de meme taille que le nombre d'objet de ArrayList
	   // String tab[] = new String[d.getTermes().size()];
	 
	    // Transformer le ArrayList en Tableau
	    //tab = d.getTermes().toArray(tab);
	  
	/*	
		//Creation d'une requete pour le modele vectoriel
		ModeleVectoriel mv = new ModeleVectoriel();
		String req = "";
		//System.out.println(c.getListeDoc().get(0).getTermes());
		mv.fDocuments = new Doc[1];//[c.getListeDoc().size()];
		//mv.fDocuments = c.getListeDoc().toArray(mv.fDocuments);
		mv.fDocuments[0]=c.getListeDoc().get(0);
		SortedMap<Doc, Double> docReq = mv.getDocuments(req);
		for (Double doub : docReq.values()) {
			if(doub!=0)
				System.out.println(doub);
		}
		System.out.println(docReq.toString());*/
	}

}
